"""PDF bank statement extraction: text/image auto-detect, OCR, account info, transaction parsing."""
import re
import pymupdf as fitz  # PyMuPDF
import numpy as np
import pandas as pd
from dateutil import parser as dtparser

# ---------------------------------------------------------------- regexes
D = r"\d{1,2}[-/. ](?:\d{1,2}|[A-Za-z]{3,9})[-/. ,]+\d{2,4}"
DATE_RE = re.compile(r"^\s*(" + D + r"|\d{4}-\d{2}-\d{2})(?!\d)")
AMT_RE = re.compile(r"(?<![\w/])\(?-?\d[\d,]*\.\d{1,2}\)?(?!\d)(?:\s?(?:\((?:Cr|Dr)\)|(?:Cr|Dr)\b\.?))?", re.I)
# serial-number column before the date (ICICI style): "1 01/04/2024 ..."
SERIAL_RE = re.compile(r"^\s*\d{1,4}\s+(?=\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}|\d{1,2}[-/. ][A-Za-z]{3,9}[-/. ,]+\d{2,4})")
OPEN_RE = re.compile(r"(opening\s*balance|balance\s*b/?f|brought\s*forward|b/f\b)", re.I)
STOP_RE = re.compile(r"(closing\s*balance|total\s|end of statement|statement summary|legends?\b|abbreviations)", re.I)
SKIP_RE = re.compile(r"(page\s*\d+|statement of account|continued|registered office|customer care|computer generated|"
                     r"toll free|www\.|this is a system|gstin|carried forward)", re.I)
HEADER_WORDS = ["date", "particulars", "narration", "description", "withdrawal", "deposit", "debit",
                "credit", "balance", "chq", "cheque", "ref", "value"]
CREDIT_HINT = re.compile(r"\b(cr|credit|salary|interest|int\.?pd|refund|deposit|received|reversal|cashback|dividend)\b", re.I)
DEBIT_HINT = re.compile(r"\b(dr|debit|withdrawal|wdl|paid|atm|pos|emi|charges?|purchase)\b", re.I)

BANKS = {"HDFC": "HDFC Bank", "SBIN": "State Bank of India", "ICIC": "ICICI Bank", "UTIB": "Axis Bank",
         "KKBK": "Kotak Mahindra Bank", "PUNB": "Punjab National Bank", "BARB": "Bank of Baroda",
         "CNRB": "Canara Bank", "UBIN": "Union Bank of India", "IDFB": "IDFC FIRST Bank", "YESB": "Yes Bank",
         "INDB": "IndusInd Bank", "BKID": "Bank of India", "IOBA": "Indian Overseas Bank", "FDRL": "Federal Bank",
         "MAHB": "Bank of Maharashtra", "CBIN": "Central Bank of India", "SIBL": "South Indian Bank"}


# ---------------------------------------------------------------- text / OCR layer
_ocr = None


def _get_ocr():
    global _ocr
    if _ocr is None:
        from rapidocr_onnxruntime import RapidOCR
        _ocr = RapidOCR()
    return _ocr


def _group_lines(words):
    """words: (x0, y_center, height, text) -> list of text lines (row clustering by y)."""
    if not words:
        return []
    hs = sorted(w[2] for w in words)
    med = hs[len(hs) // 2] or 8
    words = sorted(words, key=lambda w: (w[1], w[0]))
    lines, cur = [], [words[0]]
    cy = words[0][1]
    for w in words[1:]:
        if abs(w[1] - cy) <= 0.6 * med:
            cur.append(w)
            cy = sum(x[1] for x in cur) / len(cur)
        else:
            lines.append(cur)
            cur, cy = [w], w[1]
    lines.append(cur)
    return [" ".join(t[3] for t in sorted(l, key=lambda w: w[0])) for l in lines]


def _ocr_lines(page, dpi):
    pix = page.get_pixmap(dpi=dpi, colorspace=fitz.csRGB)
    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
    result, _ = _get_ocr()(img)
    words = []
    for box, text, _score in (result or []):
        xs, ys = [p[0] for p in box], [p[1] for p in box]
        words.append((min(xs), sum(ys) / 4, max(ys) - min(ys), text))
    return _group_lines(words)


def page_lines(page, dpi=250, force_ocr=False):
    """Auto-detect: pages with a real text layer are read directly, others go through OCR."""
    if not force_ocr and len(page.get_text().strip()) >= 40:
        ws = [(w[0], (w[1] + w[3]) / 2, w[3] - w[1], w[4]) for w in page.get_text("words")]
        return _group_lines(ws), "text"
    return _ocr_lines(page, dpi), "image (OCR)"


# ---------------------------------------------------------------- account details
def extract_account_info(text):
    end = (r"(?=\s+(?:account|a/c|acc|customer|cust|ifsc|micr|branch|address|mobile|email|pan|cif|date|"
           r"period|statement|nomination|currency|joint|city|state|phone)\b|\s*$)")
    info = {}

    def grab(key, pat, flags=re.I | re.M, grp=1):
        m = re.search(pat, text, flags)
        if m:
            info[key] = re.sub(r"\s+", " ", m.group(grp)).strip(" :-")

    grab("account_holder", r"(?:account\s*(?:holder|name)|customer\s*name|a/c\s*name|(?<!branch )(?<!bank )\bname)"
                           r"\s*[:\-]\s*(?:mr\.?|mrs\.?|ms\.?|shri|smt)?\s*([A-Za-z][A-Za-z .&']{2,60}?)" + end)
    grab("account_number", r"(?:a/?c|account)\s*(?:no|number|num|#)?\.?\s*[:\-]?\s*([Xx*\d][Xx*\d\- ]{6,24}[\dXx])")
    if "account_number" in info:
        info["account_number"] = info["account_number"].replace(" ", "")
    grab("ifsc", r"\b([A-Z]{4}0[A-Z0-9]{6})\b", flags=0)
    grab("micr", r"MICR\s*(?:code|no\.?)?\s*[:\-]?\s*(\d{9})")
    grab("branch", r"branch(?:\s*name)?\s*[:\-]\s*(.+?)" + end)
    if "branch" in info:
        info["branch"] = re.sub(r"IFSC.*$", "", info["branch"]).strip()
    grab("customer_id", r"(?:cust(?:omer)?\s*(?:id|no\.?|number)|cif)\s*[:\-]?\s*(\d{5,15})")
    grab("account_type", r"(?:account\s*type|type of account|scheme)\s*[:\-]\s*(.+?)" + end)
    m = re.search(D + r"\s*(?:to|-|till|and)\s*" + D, text, re.I)
    if m:
        info["statement_period"] = re.sub(r"\s+", " ", m.group(0))
    if "ifsc" in info and info["ifsc"][:4] in BANKS:
        info["bank"] = BANKS[info["ifsc"][:4]]
    else:
        for b in BANKS.values():
            if b.lower() in text.lower():
                info["bank"] = b
                break
    return info


# ---------------------------------------------------------------- transaction parsing
def _num(s):
    marker = re.search(r"(Cr|Dr)", s, re.I)
    v = float(re.sub(r"[^\d.]", "", re.sub(r"(Cr|Dr)", "", s, flags=re.I)) or 0)
    if s.strip().startswith(("(", "-")):
        v = -v
    return v, (marker.group(1).upper() if marker else None)


def _bal(v, marker):
    return -abs(v) if marker == "DR" else v


def _trailing_amounts(s):
    """Amount run at the END of a line (up to 3 numbers). Returns (amount strings, text before them)."""
    ms = list(AMT_RE.finditer(s))
    if ms and re.fullmatch(r"\s+\d{1,6}", s[ms[-1].end():] or "x"):   # trailing branch/code column
        s = s[:ms[-1].end()]
    if not ms or s[ms[-1].end():].strip():
        return [], s
    run = [ms[-1]]
    for m in reversed(ms[:-1]):
        if s[m.end():run[0].start()].strip() == "":
            run.insert(0, m)
        else:
            break
    run = run[-3:]
    return [m.group(0).strip() for m in run], s[:run[0].start()].strip()


def _is_header(ln):
    return sum(w in ln.lower() for w in HEADER_WORDS) >= 3


def _finalize(t):
    vals = [_num(a) for a in t["amts"]]
    amount = balance = d = None
    if len(vals) >= 3:
        (a, _), (b, _), (c, mc) = vals[-3:]
        balance = _bal(c, mc)
        if a == 0 and b != 0:
            amount, d = b, "C"
        elif b == 0 and a != 0:
            amount, d = a, "D"
        else:
            amount = b
    elif len(vals) == 2:
        amount, balance = abs(vals[0][0]), _bal(*vals[1])
        d = {"CR": "C", "DR": "D"}.get(vals[0][1])
    elif len(vals) == 1:
        amount = abs(vals[0][0])
        d = {"CR": "C", "DR": "D"}.get(vals[0][1])
    t.update(amount=abs(amount) if amount is not None else None, balance=balance, dir=d)
    t["desc"] = re.sub(r"\s+", " ", t["desc"]).strip()
    return t


def parse_transactions(lines):
    txns, cur, opening = [], None, None

    def flush():
        nonlocal cur
        if cur and cur["amts"]:
            txns.append(_finalize(cur))
        cur = None

    for page, ln in lines:
        ln = ln.strip()
        if not ln:
            continue
        if OPEN_RE.search(ln):
            am, _ = _trailing_amounts(ln)
            if am and opening is None:
                opening = _bal(*_num(am[-1]))
            flush()
            continue
        ln = SERIAL_RE.sub("", ln, count=1)
        m = DATE_RE.match(ln)
        if m:
            flush()
            rest = ln[m.end():]
            m2 = DATE_RE.match(rest)          # value date column
            if m2:
                rest = rest[m2.end():]
            am, before = _trailing_amounts(rest)
            before = re.sub(r"\s+\d{8,}\s+" + D + r"(?=\s|$)", " ", before)   # ref no + value date column
            cur = {"date": m.group(1), "page": page, "amts": am, "desc": before}
        elif cur is not None:
            if STOP_RE.search(ln):
                flush()
                continue
            if SKIP_RE.search(ln) or _is_header(ln):
                continue
            am, before = _trailing_amounts(ln)
            if am and not cur["amts"]:        # amounts wrapped onto a later line
                cur["amts"], cur["desc"] = am, cur["desc"] + " " + before
            else:                             # multi-line description
                cur["desc"] += " " + ln
    flush()
    return txns, opening


def _orient(txns):
    """Some banks print newest-first. Pick the order where running balances reconcile."""
    fwd = rev = 0
    for i in range(len(txns)):
        t = txns[i]
        if t["balance"] is None or t["amount"] is None:
            continue
        if i > 0 and txns[i - 1]["balance"] is not None:
            fwd += abs(abs(t["balance"] - txns[i - 1]["balance"]) - t["amount"]) <= 0.02
        if i + 1 < len(txns) and txns[i + 1]["balance"] is not None:
            rev += abs(abs(t["balance"] - txns[i + 1]["balance"]) - t["amount"]) <= 0.02
    return rev > fwd


def _infer_direction(txns, opening):
    prev = opening
    for t in txns:
        if t["dir"] is None and t["balance"] is not None and prev is not None and t["amount"] is not None:
            dlt = round(t["balance"] - prev, 2)
            if abs(abs(dlt) - t["amount"]) <= 0.02:
                t["dir"] = "C" if dlt > 0 else "D"
        if t["dir"] is None:
            c, dd = bool(CREDIT_HINT.search(t["desc"])), bool(DEBIT_HINT.search(t["desc"]))
            t["dir"] = "C" if c and not dd else "D"
        if t["balance"] is not None:
            prev = t["balance"]


def _to_date(s):
    try:
        return pd.Timestamp(dtparser.parse(s, dayfirst=True))
    except Exception:
        return pd.NaT


def process_pdf(data: bytes, password: str = "", dpi: int = 250, force_ocr: bool = False):
    doc = fitz.open(stream=data, filetype="pdf")
    if doc.needs_pass and not (password and doc.authenticate(password)):
        raise PermissionError("PDF is password protected - enter the correct password in the sidebar.")
    lines, kinds = [], []
    for i, p in enumerate(doc):
        ls, kind = page_lines(p, dpi, force_ocr)
        kinds.append(kind)
        lines += [(i + 1, l) for l in ls]
    info = extract_account_info("\n".join(l for _, l in lines))
    txns, opening = parse_transactions(lines)
    warnings = []
    reversed_order = _orient(txns)
    if reversed_order:
        txns.reverse()
        opening = None
        warnings.append("Statement was newest-first; rows re-ordered chronologically.")
    _infer_direction(txns, opening)

    rows, prev = [], opening
    for t in txns:
        dr = t["amount"] if t["dir"] == "D" else None
        cr = t["amount"] if t["dir"] == "C" else None
        chk = "n/a"
        if t["balance"] is not None and prev is not None:
            exp = prev + (cr or 0) - (dr or 0)
            chk = "OK" if abs(exp - t["balance"]) <= 0.02 else "MISMATCH"
        if t["balance"] is not None:
            prev = t["balance"]
        rows.append(dict(date=_to_date(t["date"]), description=t["desc"], debit=dr, credit=cr,
                         balance=t["balance"], page=t["page"], balance_check=chk))
    df = pd.DataFrame(rows, columns=["date", "description", "debit", "credit", "balance", "page", "balance_check"])
    if not df.empty:
        dup = df.duplicated(["date", "description", "debit", "credit", "balance"], keep="first") & df.balance.notna()
        df["possible_duplicate"] = dup
        if df.date.isna().any():
            warnings.append(f"{int(df.date.isna().sum())} row(s) have unparseable dates.")
        if (df.balance_check == "MISMATCH").any():
            warnings.append(f"{int((df.balance_check == 'MISMATCH').sum())} row(s) fail balance reconciliation - verify them.")
        if dup.any():
            warnings.append(f"{int(dup.sum())} possible duplicate row(s) flagged.")
    else:
        warnings.append("No transactions detected - layout not recognised. Try 'Force OCR' or a higher DPI.")
    meta = dict(pages=len(kinds), page_types=kinds, opening_balance=opening, warnings=warnings,
                pdf_type=("image-based" if all(k.startswith("image") for k in kinds)
                          else "text-based" if all(k == "text" for k in kinds) else "mixed"))
    return dict(info=info, df=df, meta=meta)
