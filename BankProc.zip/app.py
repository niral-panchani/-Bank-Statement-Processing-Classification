import io
import pandas as pd
import streamlit as st
from extractor import process_pdf
from classifier import TxnClassifier, CATEGORIES

st.set_page_config(page_title="Bank Statement Processor", page_icon="🏦", layout="wide")
st.title("🏦 Bank Statement Processing & Classification")
st.caption("Text + scanned PDFs → extraction → rule-based + ML classification (no LLM) → Excel / CSV")


@st.cache_resource
def get_clf():
    return TxnClassifier()


clf = get_clf()


@st.cache_data(show_spinner="Extracting (OCR can take a while for scanned PDFs)...")
def run_extract(name, data, password, dpi, force_ocr):
    return process_pdf(data, password, dpi, force_ocr)


def summarize(df):
    return (df.groupby("category")
              .agg(transactions=("description", "count"), total_debit=("debit", "sum"), total_credit=("credit", "sum"))
              .reset_index().sort_values("total_debit", ascending=False))


def build_excel(info_df, txn_df, summ_df):
    bio = io.BytesIO()
    with pd.ExcelWriter(bio, engine="openpyxl", datetime_format="DD-MM-YYYY", date_format="DD-MM-YYYY") as w:
        info_df.to_excel(w, sheet_name="Account Info", index=False)
        txn_df.to_excel(w, sheet_name="Transactions", index=False)
        summ_df.to_excel(w, sheet_name="Category Summary", index=False)
        for ws in w.book.worksheets:
            for col in ws.columns:
                width = max(len(str(c.value)) if c.value is not None else 0 for c in col)
                ws.column_dimensions[col[0].column_letter].width = min(max(width + 2, 10), 60)
            ws.freeze_panes = "A2"
    return bio.getvalue()


with st.sidebar:
    st.header("Settings")
    password = st.text_input("PDF password (if protected)", type="password")
    force_ocr = st.checkbox("Force OCR on all pages", value=False)
    dpi = st.slider("OCR render DPI", 150, 400, 250, 50)
    st.markdown("Page type (text vs image) is auto-detected per page.")

files = st.file_uploader("Upload bank statement PDF(s)", type=["pdf"], accept_multiple_files=True)
if not files:
    st.info("Upload one or more PDF statements to begin.")
    st.stop()

all_tx, all_info, corrections = [], [], []
for f in files:
    st.divider()
    st.subheader(f"📄 {f.name}")
    try:
        res = run_extract(f.name, f.getvalue(), password, dpi, force_ocr)
    except PermissionError as e:
        st.error(str(e))
        continue
    except Exception as e:
        st.error(f"Could not process this file: {e}")
        continue

    info, meta = res["info"], res["meta"]
    df = clf.classify_df(res["df"])
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("PDF type", meta["pdf_type"])
    c2.metric("Pages", meta["pages"])
    c3.metric("Transactions", len(df))
    c4.metric("Uncategorized", int((df.category == "Uncategorized").sum()) if len(df) else 0)
    for w in meta["warnings"]:
        st.warning(w)
    if df.empty:
        continue

    tab1, tab2, tab3 = st.tabs(["Transactions (editable category)", "Summary", "Account details"])
    with tab1:
        cols = ["date", "description", "counterparty", "debit", "credit", "balance", "category", "method",
                "confidence", "balance_check", "possible_duplicate", "page"]
        edited = st.data_editor(
            df[cols], key=f"ed_{f.name}", use_container_width=True, hide_index=True,
            disabled=[c for c in cols if c != "category"],
            column_config={"category": st.column_config.SelectboxColumn("category", options=CATEGORIES),
                           "date": st.column_config.DateColumn("date", format="DD-MM-YYYY")})
        chg = edited.category != df.category
        if chg.any():
            corrections.append((df.description[chg].tolist(), edited.category[chg].tolist()))
        edited.insert(0, "source_file", f.name)
        all_tx.append(edited)
    with tab2:
        s = summarize(edited)
        a, b = st.columns(2)
        a.dataframe(s, hide_index=True, use_container_width=True)
        b.bar_chart(s.set_index("category")["total_debit"])
        m = edited.dropna(subset=["date"]).assign(month=lambda d: d.date.dt.to_period("M").astype(str))
        st.bar_chart(m.groupby("month")[["debit", "credit"]].sum())
    with tab3:
        st.table(pd.DataFrame({"field": list(info.keys()), "value": list(info.values())}))
        if meta["opening_balance"] is not None:
            st.write(f"Opening balance: **{meta['opening_balance']:,.2f}**")
    all_info.append(pd.DataFrame({"file": f.name, "field": list(info.keys()), "value": list(info.values())}))

if corrections and st.sidebar.button("🧠 Apply my category corrections (retrain)"):
    for d, c in corrections:
        clf.learn(d, c)
    st.rerun()

if all_tx:
    st.divider()
    st.subheader("⬇️ Export")
    txn = pd.concat(all_tx, ignore_index=True)
    info_df = pd.concat(all_info, ignore_index=True) if all_info else pd.DataFrame(columns=["file", "field", "value"])
    out = txn.copy()
    out["date"] = out["date"].dt.strftime("%d-%m-%Y")
    e1, e2, _ = st.columns([1, 1, 3])
    e1.download_button("Excel (.xlsx)", build_excel(info_df, txn, summarize(txn)), "transactions.xlsx",
                       "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    e2.download_button("CSV (.csv)", out.to_csv(index=False).encode("utf-8"), "transactions.csv", "text/csv")
