"""Non-LLM transaction classifier: (1) user overrides -> (2) heuristic rules -> (3) TF-IDF + Logistic Regression."""
import re
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

# (category, side: cr/dr/both, regex) - ORDER MATTERS: specific merchants first, generic channels last
RULES = [
    ("Salary & Income", "cr", r"\b(salary|sal cr|payroll|stipend|wages)\b"),
    ("Interest Earned", "cr", r"\b(int\.?\s*pd|interest (credit|paid)|int(erest)? (cr|credit)|sb int|credit interest)\b"),
    ("Refund & Cashback", "cr", r"\b(refund|reversal|cashback|cash back|chargeback)\b"),
    ("Dividend", "cr", r"\b(dividend)\b"),
    ("Cash Deposit", "cr", r"\b(cash dep|cdm|cash deposit|by cash)\b"),
    ("ATM Withdrawal", "dr", r"\b(atm|atw|nwd|nfs|cash wdl|cash withdrawal|awb)\b"),
    ("Taxes", "dr", r"\b(income tax|tds|advance tax|cbdt|challan|property tax)\b"),
    ("Bank Charges & Fees", "dr", r"\b(charges?|chgs?|fee|sms alert|amc|annual fee|min(imum)? bal|penalty|gst|igst|cgst|sgst|service tax|processing fee)\b"),
    ("EMI & Loans", "dr", r"\b(emi|loan|ach d|nach|bajaj fin|home credit|lic housing|repayment|instalment|installment)\b"),
    ("Insurance", "dr", r"\b(insurance|lic of india|lic premium|policybazaar|premium|hdfc life|sbi life|icici pru|star health|acko)\b"),
    ("Investments", "dr", r"\b(mutual fund|sip|zerodha|groww|upstox|kuvera|nse|bse|ppf|nps|demat|angel one|indmoney|smallcase)\b"),
    ("Food & Dining", "dr", r"\b(swiggy|zomato|dominos?|pizza|mcdonalds?|kfc|burger|restaurant|cafe|starbucks|barbeque|food|eatsure|bakery|dhaba|chai)\b"),
    ("Groceries", "dr", r"\b(bigbasket|big basket|blinkit|zepto|grofers|d[- ]?mart|reliance fresh|jiomart|more retail|supermarket|kirana|grocery|instamart|milk|vegetable)\b"),
    ("Fuel", "dr", r"\b(petrol|diesel|fuel|hpcl|bpcl|iocl|indian oil|bharat petroleum|hindustan petroleum|shell|nayara)\b"),
    ("Travel & Transport", "dr", r"\b(uber|ola|rapido|irctc|redbus|makemytrip|goibibo|cleartrip|indigo|air india|spicejet|vistara|metro|fastag|toll|railway|yatra|abhibus|cab|taxi|flight)\b"),
    ("Shopping", "dr", r"\b(amazon|amzn|flipkart|myntra|ajio|meesho|nykaa|lenskart|croma|reliance digital|decathlon|tata cliq|snapdeal|shoppers stop|lifestyle|pantaloons|westside|zudio|ikea)\b"),
    ("Mobile & Internet", "dr", r"\b(recharge|airtel|jio|vodafone|vi|bsnl|act fibernet|hathway|prepaid|broadband)\b"),
    ("Utilities & Bills", "dr", r"\b(electricity|bescom|msedcl|torrent power|adani electricity|piped gas|gas bill|igl|mahanagar|water bill|bill ?desk|billpay|bbps|dth|tata play|tata sky|dish tv|municipal|gujarat gas|ugvcl|dgvcl|pgvcl|mgvcl|postpaid)\b"),
    ("Entertainment & Subscriptions", "dr", r"\b(netflix|spotify|hotstar|prime video|youtube|bookmyshow|pvr|inox|gaana|sonyliv|zee5|apple|google play|playstore|steam|dream11|subscription)\b"),
    ("Healthcare", "dr", r"\b(hospital|pharmacy|apollo|medplus|1mg|pharmeasy|netmeds|clinic|diagnostic|doctor|medical|practo|dental)\b"),
    ("Education", "dr", r"\b(school|college|university|tuition|coursera|udemy|byju|unacademy|exam fee|upgrad)\b"),
    ("Rent & Housing", "dr", r"\b(rent|landlord|maintenance|society|nobroker|nestaway)\b"),
    ("Cheque", "both", r"\b(chq|cheque|clg|clearing)\b"),
    ("Wallet & Payments", "both", r"\b(paytm|phonepe|gpay|google pay|amazon pay|mobikwik|freecharge|bhim|wallet|razorpay|cred)\b"),
    ("Bank Transfer (NEFT/IMPS/RTGS)", "both", r"\b(neft|imps|rtgs|fund transfer|trf|transfer|tpt|ib funds)\b"),
    ("UPI Transfer", "both", r"\b(upi)\b"),
]
COMPILED = [(c, s, re.compile(p, re.I)) for c, s, p in RULES]
CATEGORIES = sorted({c for c, _, _ in RULES} | {"Uncategorized"})

# Seed examples for the ML model (includes merchants NOT in the rules so the model can generalise via char n-grams)
SEED = {
    "Salary & Income": "salary|salary credit|payroll|monthly salary|stipend|wages|bonus payout",
    "Interest Earned": "interest credit|int pd|savings interest|sb interest|credit interest",
    "Refund & Cashback": "refund|order refund|cashback|reversal|chargeback",
    "Dividend": "dividend|dividend credit|div payout",
    "Cash Deposit": "cash deposit|cdm deposit|by cash|cash dep",
    "ATM Withdrawal": "atm withdrawal|nfs atm|cash wdl|atm cash|awb",
    "Taxes": "income tax|tds|advance tax|cbdt|challan|property tax",
    "Bank Charges & Fees": "sms charges|annual fee|amc charges|gst on charges|min balance penalty|processing fee|debit card fee",
    "EMI & Loans": "emi|home loan emi|car loan|nach debit|loan repayment|bajaj finance|personal loan",
    "Insurance": "lic premium|health insurance|hdfc life|star health|policybazaar|term plan premium|acko",
    "Investments": "sip|mutual fund|zerodha|groww|ppf deposit|nps|demat|upstox|kuvera",
    "Food & Dining": "swiggy|zomato|dominos pizza|mcdonalds|kfc|starbucks|chaayos|barista|restaurant|cafe coffee day|haldiram|biryani|burger king",
    "Groceries": "bigbasket|blinkit|zepto|dmart|jiomart|reliance fresh|supermarket|kirana store|big bazaar|instamart",
    "Fuel": "petrol pump|hpcl|bpcl|indian oil|shell fuel|diesel|nayara energy|fuel station",
    "Travel & Transport": "uber|ola cabs|rapido|irctc|redbus|makemytrip|indigo airlines|fastag|metro card|ixigo",
    "Shopping": "amazon|flipkart|myntra|ajio|meesho|nykaa|croma|decathlon|lenskart|tata cliq",
    "Mobile & Internet": "airtel recharge|jio recharge|vi prepaid|bsnl|act fibernet|hathway broadband",
    "Utilities & Bills": "electricity bill|bescom|torrent power|gas bill|water bill|dth recharge|tata play|bbps bill|uttar gujarat vij",
    "Entertainment & Subscriptions": "netflix|spotify|hotstar|prime video|bookmyshow|youtube premium|zee5|sonyliv",
    "Healthcare": "apollo pharmacy|hospital|medplus|pharmeasy|1mg|diagnostic lab|clinic|dental care|practo",
    "Education": "school fees|college fee|tuition|coursera|udemy|byjus|university exam fee",
    "Rent & Housing": "house rent|rent payment|landlord|society maintenance|nobroker",
    "Cheque": "chq paid|cheque deposit|clearing|chq no|cheque issued",
    "Wallet & Payments": "paytm wallet|phonepe|google pay|amazon pay|mobikwik|freecharge|razorpay",
    "Bank Transfer (NEFT/IMPS/RTGS)": "neft transfer|imps transfer|rtgs|fund transfer|ib funds transfer|trf to",
    "UPI Transfer": "upi payment|upi to friend|upi ramesh|upi sent|upi received from",
}
TEMPLATES = ["{}", "UPI {} 4521", "POS {} MUMBAI", "{} PAYMENT", "NEFT {} REF77", "IMPS {} 7788"]
# long, unambiguous keywords matched even when OCR glued words together (spaces/punctuation ignored)
SAFE = {"salary": ("Salary & Income", True), "payroll": ("Salary & Income", True), "refund": ("Refund & Cashback", True),
        "cashback": ("Refund & Cashback", True), "dividend": ("Dividend", True), "interest": ("Interest Earned", True)}
GENERIC = {"UPI Transfer", "Bank Transfer (NEFT/IMPS/RTGS)", "Cheque", "Wallet & Payments"}
CREDIT_CATS = {c for c, side, _ in RULES if side == "cr"}
STOP = {"upi", "dr", "cr", "neft", "imps", "rtgs", "pos", "payment", "transfer", "to", "from", "by", "ref", "txn", "ib", "atm"}


def normalize(desc: str) -> str:
    d = str(desc).lower()
    d = re.sub(r"@[a-z0-9.\-]+", " ", d)             # strip UPI handles (@ybl, @okhdfcbank...)
    d = re.sub(r"[/_|:,;()*#]", " ", d)
    return re.sub(r"\s+", " ", d).strip()


def ml_text(desc: str) -> str:
    return re.sub(r"\d+", " ", normalize(desc)).strip()


MERCHANTS = {
    "amazonpay": "Amazon Pay", "amazon": "Amazon", "amzn": "Amazon", "flipkart": "Flipkart", "myntra": "Myntra",
    "swiggy": "Swiggy", "zomato": "Zomato", "dominos": "Dominos", "mcdonald": "McDonalds", "starbucks": "Starbucks",
    "chaayos": "Chaayos", "haldiram": "Haldirams", "kfc": "KFC", "blinkit": "Blinkit", "zepto": "Zepto",
    "bigbasket": "BigBasket", "jiomart": "JioMart", "dmart": "DMart", "uber": "Uber", "olacabs": "Ola", "rapido": "Rapido",
    "irctc": "IRCTC", "redbus": "RedBus", "makemytrip": "MakeMyTrip", "indigo": "IndiGo", "netflix": "Netflix",
    "spotify": "Spotify", "hotstar": "Hotstar", "bookmyshow": "BookMyShow", "phonepe": "PhonePe", "paytm": "Paytm",
    "googlepay": "Google Pay", "gpay": "Google Pay", "zerodha": "Zerodha", "groww": "Groww", "bajajfin": "Bajaj Finance",
    "hdfclife": "HDFC Life", "licofindia": "LIC", "licpremium": "LIC", "apollo": "Apollo", "pharmeasy": "PharmEasy",
    "netmeds": "Netmeds", "airtel": "Airtel", "vodafone": "Vodafone", "bsnl": "BSNL", "ugvcl": "UGVCL", "dgvcl": "DGVCL",
    "pgvcl": "PGVCL", "mgvcl": "MGVCL", "torrentpower": "Torrent Power", "bescom": "BESCOM", "indianoil": "Indian Oil",
    "hpcl": "HPCL", "bpcl": "BPCL", "nykaa": "Nykaa", "meesho": "Meesho", "ajio": "Ajio", "croma": "Croma",
    "decathlon": "Decathlon", "lenskart": "Lenskart", "coursera": "Coursera", "udemy": "Udemy",
}
_MERCH_KEYS = sorted(MERCHANTS, key=len, reverse=True)
APPS = {"phonepe", "paytm", "googlepay", "gpay"}   # payment apps are not the merchant - last resort only
NO_COUNTERPARTY = {"ATM Withdrawal", "Interest Earned", "Bank Charges & Fees", "Taxes", "Cash Deposit"}
NOISE = {"upi", "dr", "cr", "neft", "imps", "rtgs", "pos", "payment", "transfer", "to", "from", "by", "ref", "txn",
         "ib", "atm", "ach", "achd", "nach", "ecom", "mmt", "paid", "sent", "received", "int", "pd", "wdl", "nfs",
         "chq", "clg", "bill", "billpay", "billdesk", "emi", "salary", "refund", "by transfer", "to transfer", "bytransfer", "totransfer"}
_PREFIX = r"(?:upi|neft|imps|rtgs|pos|achd|ach|nach|ecom|mmt)"
_DATE = re.compile(r"\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}")


def _smart_split(word: str) -> str:
    """Split OCR-merged ALL-CAPS text into words, but only if every piece is a real 3+ letter word."""
    if " " in word or len(word) < 8 or not word.isalpha():
        return word
    try:
        import wordninja
        parts = wordninja.split(word.lower())
        if len(parts) > 1 and all(len(p) >= 3 for p in parts):
            return " ".join(parts)
    except ImportError:
        pass
    return word


def counterparty(desc: str, category: str = "") -> str:
    """Who the money went to / came from. Works on clean text and on OCR output with missing spaces."""
    if category in NO_COUNTERPARTY:
        return ""
    s = re.sub(r"@\S+", "", str(desc))                      # drop UPI handles
    s = re.sub(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", " ", s)          # drop IFSC codes
    flat = re.sub(r"[^a-z]", "", s.lower())
    for k in _MERCH_KEYS:                                    # 1) known merchant (space-insensitive)
        if k in flat and k not in APPS:
            return MERCHANTS[k]
    for part in re.split(r"[/|*]|\s*-\s*", s):        # 2) structural: first meaningful segment
        p = _DATE.sub(" ", part)
        p = re.sub(r"\d+", " ", p).strip(" -.:,")
        p = re.sub(r"(?i)^" + _PREFIX + r"\b[\s-]*", "", p).strip()
        if " " not in p and len(p) >= 12:                    # merged token: strip glued prefix (POSAMAZON...)
            p = re.sub(r"(?i)^" + _PREFIX, "", p)
        p = re.sub(r"(?i)\s+salary\b.*$", "", re.sub(r"\s+", " ", p)).strip(" -.:,")
        if len(p) < 3 or not re.search(r"[A-Za-z]{3}", p) or p.lower() in NOISE:
            continue
        return " ".join(w.capitalize() for w in _smart_split(p).split())[:40]
    for k in _MERCH_KEYS:                                    # 3) only a payment app is visible
        if k in flat:
            return MERCHANTS[k]
    return ""


class TxnClassifier:
    def __init__(self, threshold: float = 0.30):
        self.threshold = threshold
        self.X, self.y = [], []
        for cat, ex in SEED.items():
            for e in ex.split("|"):
                for t in TEMPLATES:
                    self.X.append(ml_text(t.format(e)))
                    self.y.append(cat)
        self.overrides = {}
        self._fit()

    def _fit(self):
        self.pipe = make_pipeline(TfidfVectorizer(analyzer="char", ngram_range=(3, 5), sublinear_tf=True),
                                  LogisticRegression(C=30, max_iter=2000))
        self.pipe.fit(self.X, self.y)

    def learn(self, descriptions, categories):
        """User corrections: remembered exactly (override) and added to the training set (retrain)."""
        for d, c in zip(descriptions, categories):
            self.overrides[ml_text(d)] = c
            for _ in range(5):
                self.X.append(ml_text(d))
                self.y.append(c)
        self._fit()

    def classify(self, desc: str, is_credit: bool):
        key = ml_text(desc)
        if key in self.overrides:
            return self.overrides[key], "user-feedback", 1.0
        d = normalize(desc)
        generic = None
        for cat, side, rx in COMPILED:
            if (side == "cr" and not is_credit) or (side == "dr" and is_credit):
                continue
            if rx.search(d):
                if cat in GENERIC:               # channel only (UPI/NEFT...) - let ML look for a merchant first
                    generic = generic or cat
                    continue
                return cat, "rule", 1.0
        flat = re.sub(r"[^a-z]", "", d)
        for k, (cat, cr_side) in SAFE.items():
            if k in flat and cr_side == is_credit:
                return cat, "rule", 0.9
        ml_cat, ml_p = None, 0.0
        if key:
            p = self.pipe.predict_proba([key])[0]
            i = p.argmax()
            ml_cat, ml_p = self.pipe.classes_[i], float(p[i])
        if generic:
            if ml_cat and ml_cat not in GENERIC and ml_p >= 0.45 and (not is_credit or ml_cat in CREDIT_CATS):
                return ml_cat, "ml", round(ml_p, 2)
            return generic, "rule", 1.0
        if ml_cat and ml_p >= self.threshold and (is_credit == (ml_cat in CREDIT_CATS) or ml_cat in GENERIC):
            return ml_cat, "ml", round(ml_p, 2)
        return "Uncategorized", "none", 0.0

    def classify_df(self, df: pd.DataFrame) -> pd.DataFrame:
        out = df.copy()
        res = [self.classify(r.description, bool(r.credit and r.credit > 0)) for r in out.itertuples()]
        out["category"] = [r[0] for r in res]
        out["method"] = [r[1] for r in res]
        out["confidence"] = [r[2] for r in res]
        out["counterparty"] = [counterparty(d, c) for d, c in zip(out.description, out.category)]
        return out
