import fitz
rows = [
("01/04/2024","UPI/412345678901/SWIGGY/swiggy@ybl/Payment",None,"450.00","49,550.00"),
("02/04/2024","NEFT-CR-ACME CORP-SALARY MAR 2024","60,000.00",None,"1,09,550.00"),
("03/04/2024","ATM WDL NFS 4521 MUMBAI",None,"5,000.00","1,04,550.00"),
("05/04/2024","UPI/998877665544/RAMESH KUMAR/ramesh@okhdfcbank",None,"1,200.00","1,03,350.00"),
("06/04/2024","POS AMAZON PAY INDIA PRIVATE LIMITED BANGALORE",None,"2,499.00","1,00,851.00"),
("08/04/2024","ACH D- BAJAJ FIN LTD EMI 8841",None,"7,500.00","93,351.00"),
("10/04/2024","INT.PD 01-01-2024 TO 31-03-2024","312.00",None,"93,663.00"),
("12/04/2024","UPI/556677889900/CHAAYOS KORAMANGALA/chaayos@paytm",None,"380.00","93,283.00"),
("15/04/2024","BILLDESK UGVCL ELECTRICITY BILL",None,"1,850.00","91,433.00"),
]
doc = fitz.open(); pg = doc.new_page(width=595, height=842)
hdr = ["HDFC BANK LTD","Statement of Account","Account Name : MR NIRAL PATEL","Account No : 50100234567890 Customer ID : 12345678",
"Branch : GANDHINAGAR SECTOR 11 IFSC : HDFC0001234","MICR Code : 380240002","Statement Period : 01/04/2024 to 30/04/2024"]
y=40
for h in hdr: pg.insert_text((40,y),h,fontsize=10); y+=15
y+=10
for x,t in zip((40,110,330,400,480),["Date","Narration","Deposit","Withdrawal","Balance"]): pg.insert_text((x,y),t,fontsize=9)
y+=15
pg.insert_text((40,y),"01/04/2024",fontsize=8); pg.insert_text((110,y),"Opening Balance",fontsize=8); pg.insert_text((480,y),"50,000.00",fontsize=8); y+=14
for d,desc,cr,dr,bal in rows:
    pg.insert_text((40,y),d,fontsize=8)
    if len(desc)>42:
        pg.insert_text((110,y),desc[:42],fontsize=8); pg.insert_text((110,y+10),desc[42:],fontsize=8)
    else: pg.insert_text((110,y),desc,fontsize=8)
    if cr: pg.insert_text((330,y),cr,fontsize=8)
    if dr: pg.insert_text((400,y),dr,fontsize=8)
    pg.insert_text((480,y),bal,fontsize=8); y+=26
pg.insert_text((40,y),"Closing Balance 91,433.00",fontsize=8)
pg.insert_text((40,820),"Page 1 of 1  This is a computer generated statement",fontsize=7)
doc.save("sample_text.pdf")
# image-only version
pix = doc[0].get_pixmap(dpi=200); d2 = fitz.open(); p2 = d2.new_page(width=595,height=842)
p2.insert_image(p2.rect, pixmap=pix); d2.save("sample_scanned.pdf")
